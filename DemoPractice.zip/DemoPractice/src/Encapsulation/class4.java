package Encapsulation;

public class class4 {
	
	private int a;
	private String b;
	
	public int getA() {
		return a;
	}
	public String getB() {
		return b;
	}
	class4(int a, String b){
		this.a=a;
		this.b=b;
	}

}
