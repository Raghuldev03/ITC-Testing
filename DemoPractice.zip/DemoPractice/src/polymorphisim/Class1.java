package polymorphisim;

public class Class1 {
   void a (int a) {
		System.out.println(a);
	}
   void a(int a,int b) {
	   System.out.println(a+b);
   }
	public static void main(String[] args) {
		new Class1().a(10,20);

	}

}
