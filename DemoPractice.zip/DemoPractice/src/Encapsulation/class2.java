package Encapsulation;

public class class2 {

	public static void main(String[] args) {
		class1 t=new class1();
		t.setName("Raghul");
		t.setA(23);
		System.out.println(t.getName());
		System.out.println(t.getA());

		// Class 4 
		
		class4 t1=new class4(400,"BMW");
		System.out.println(t1.getA());
		System.out.println(t1.getB());
	}

}
