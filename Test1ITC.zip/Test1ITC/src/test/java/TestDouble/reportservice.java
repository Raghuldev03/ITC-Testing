package TestDouble;

public class reportservice {
	
	private mailservice emailservices;
	
	public reportservice(mailservice emailServices) {
		this.emailservices=emailServices;
				}
	public String generateReport() {
		return "Report Generated";
	}
}
