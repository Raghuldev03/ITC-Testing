package loops;

public class class1 {

	public static void main(String[] args) {
	int i=25;
	if(i==10) {
		System.out.println("not Match");
	}
	else if(i==25) {
		System.out.println("Match");
	}
	else {
		System.out.println("no Match values here ");
	}
	}

}
