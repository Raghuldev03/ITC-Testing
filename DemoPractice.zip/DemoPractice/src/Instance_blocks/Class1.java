package Instance_blocks;

public class Class1 {
	int a=10; // instance block will first print
	Class1(){
		System.out.println("From constructor 1...");
	}
	Class1(int x){
		System.out.println("From Para constructor...");
	}
	{
		System.out.println("From Para Instance Block..");
	}
	public static void main(String[] args) {
		//new Class1();
		new Class1(10);
	}

}
