package Constuctor;

public class Class3 {
		int a;
		String b;
		double c;
		
		Class3(){
			a=10;
			b="Name";
			c=8.9;
		}
	void ds() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
	public static void main(String[] args) {
		Class3 t=new Class3();
		t.ds();

	}

}
