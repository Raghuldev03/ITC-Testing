package Package_one;

public class Static_Variable {
	static int a=10;
	static int b=90;
	void m1() {
	System.out.println(Static_Variable.b);
	}
	public static void main(String[] args) {
		System.out.println(Static_Variable.a);
		Static_Variable t= new Static_Variable();
		t.m1();
	}

}
