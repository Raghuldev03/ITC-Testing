package Inheritance;

class q{
	q(){
		System.out.println("parent constructor....");
	}
}
public class class2 extends q{
	
	class2(){
		this(10);
		System.out.println("child constructor....");
	}
	class2(int a){
		super();
		System.out.println("child 1 para constructor....");
	}

	public static void main(String[] args) {
		
		new class2();
	}

}
