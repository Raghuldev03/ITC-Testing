package Method;

public class Class1 {
	 void m1() {
		 System.out.println(10 + " From Instance method");
	 }
	 static void m2() {
		 System.out.println(20 + " From static method");
	 }
	public static void main(String[] args) {
		Class1.m2();
		Class1 t=new Class1();
		t.m1();

	}

}
