package Package_one;

public class Instance_variable {
	int a=10;
	void m1() {
		int b=90;
		System.out.println(b);
	}
	public static void main(String[] args) {
		Instance_variable t=new Instance_variable();
		System.out.println(t.a);
		t.m1();
	}
}
