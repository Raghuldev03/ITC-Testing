package TestDouble;

public class DummyEmailService implements mailservice{
	@Override
	public void sendEmail(String message) {
		// do nothing
	}
}
