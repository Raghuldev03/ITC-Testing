package Constuctor;

public class Class2 {
    static int id; // default value of data type
    static String name;
    static float height;
    static boolean present ;
	public static void main(String[] args) {
		System.out.println(id);
		System.out.println(name);
		System.out.println(height);
		System.out.println(present);

	}

}
