package Collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class class6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v1 = new Vector();  //a vector with default constructor
        Vector v2 = new Vector(20);  // a vector of given Size
        //initialize vector v2 with values
        v2.add(10);
        v2.add(20);
        v2.add(30);
        Vector v3 = new Vector(30, 10); // a vector of given Size and Increment
         // create a vector v4 with given collection
        List<String> aList = new ArrayList<>();
        aList.add("one");
        aList.add("two");
        Vector v4 = new Vector(aList);
        //print contents of each vector
       System.out.println("Vector v1 Contents:" + v1);
       System.out.println("Vector v2 Contents:" + v2);
       System.out.println("Vector v3 Contents:" + v3);
       System.out.println("Vector v4 Contents:" + v4);

	}

}
