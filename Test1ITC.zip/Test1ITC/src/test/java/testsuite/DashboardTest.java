package testsuite;

import org.testng.annotations.Test;

public class DashboardTest {
  @Test(priority=1)
  public void f() {
	  System.out.println("From Dashboard");
  }
}
