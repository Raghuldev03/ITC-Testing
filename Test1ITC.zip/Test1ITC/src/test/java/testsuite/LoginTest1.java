package testsuite;

import org.testng.annotations.Test;

public class LoginTest1 {
  @Test
  public void testValidLogin() {
	  System.out.println("Login Test Passed");
  }
}
