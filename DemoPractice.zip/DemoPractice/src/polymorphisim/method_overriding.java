package polymorphisim;

class A{
	
	A(){
		System.out.println("From Parent constructor...");
	}
	void fun(String a) {
		System.out.println("From Parent function..." + a);
	}
}
public class method_overriding extends A{
	 method_overriding(){
		 System.out.println("From child constructor...");
	 }
	 void fun(String b) {
		 	b="raghul";
			System.out.println("From child function..." + b);
		}
	public static void main(String[] args) {
		new method_overriding().fun("Ram");

	}

}
