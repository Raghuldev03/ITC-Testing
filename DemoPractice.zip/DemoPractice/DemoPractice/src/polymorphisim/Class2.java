package polymorphisim;

public class Class2 {

	public static void main(String[] args) {
		// operator overloading
		
		System.out.println(10+20);
		System.out.println(10+" Ram");
		System.out.println("Ram "+"Raghul");
		System.out.println("Ram "+20);
		System.out.println("Ram"+10+"raghul");

	}

}
