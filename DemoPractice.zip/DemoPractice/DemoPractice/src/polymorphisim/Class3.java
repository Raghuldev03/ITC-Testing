package polymorphisim;

class shape {
	void draw() {
		System.out.println("no shape");
	}
}
class circle extends shape{
	void draw() {
		System.out.println("Circle");
	}
}
class rectangle extends shape{
	void draw() {
		System.out.println("rectangle");
	}
}
class triangle extends shape{
	void draw() {
		System.out.println("triangle");
	}
}
public class Class3 {

	public static void main(String[] args) {
		
		shape t=new circle();
		t.draw();
		shape t1=new triangle();
		t1.draw();
	}

}
