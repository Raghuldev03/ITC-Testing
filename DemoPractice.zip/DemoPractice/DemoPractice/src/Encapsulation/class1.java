package Encapsulation;

public class class1 {
	
	private String name;
	private int a;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		if(a>0){
		 this.a = a;
		}
	}

}
