package Collections;

import java.util.ArrayDeque;
import java.util.Deque;

public class deque {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<Integer> deque = new ArrayDeque<Integer>(8);
	      // use add() method to add elements in the deque
	      deque.add(100);
	      deque.add(200);
	      deque.add(150);
	      deque.add(95);
	      // Print all the elements of the original deque
	      System.out.println("Elements of the original deque:");
	      for (Integer number : deque) {
	         System.out.println("Number = " + number);
	      }
	      int retval = deque.pollFirst();
	      System.out.println("Removed element: " + retval);
	      // printing all the elements available in deque after using pollFirst()
	      for (Integer number : deque) {
	         System.out.println("Number = " + number);
	}
	}
}
