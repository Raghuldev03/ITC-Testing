package Collections;

import java.util.LinkedList;
import java.util.List;

public class Class4 {
	int id;
	String name,author,publisher;
	int quantity;
	Class4(int id, String name, String author, String publisher, int quantity) {
	    this.id = id;
	    this.name = name;
	    this.author = author;
	    this.publisher = publisher;
	    this.quantity = quantity;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Class4> list=new LinkedList<Class4>();
	    //Creating Books
		Class4 b1=new Class4(101,"Let us C","Yashwant Kanetkar","BPB",8);
		Class4 b2=new Class4(102,"Data Communications & Networking","Forouzan","Mc Graw Hill",4);
		Class4 b3=new Class4(103,"Operating System","Galvin","Wiley",6);
	    //Adding Books to list
	    list.add(b1);
	    list.add(b2);
	    list.add(b3);
	    //Traversing list
	    for(Class4 b:list){
	    System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);
	    }
	}
}
