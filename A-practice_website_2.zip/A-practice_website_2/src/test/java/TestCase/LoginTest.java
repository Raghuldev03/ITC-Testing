package TestCase;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import POM.CheckoutPage;
import POM.LoginPage;
import POM.ProductPage;
import Testsetup.basetest;

import java.time.Duration;

public class LoginTest extends basetest {

    @DataProvider(name = "loginData", parallel = false)
    public Object[][] credentials() {
        return new Object[][]{
            {"standard_user", "secret_sauce", "John", "Doe", "12345"},
            {"problem_user", "secret_sauce", "Alice", "Wonder", "45678"},
            {"performance_glitch_user", "secret_sauce", "Bob", "Lag", "78901"},
            {"error_user", "secret_sauce", "Eve", "Error", "11223"},
            {"visual_user", "secret_sauce", "Vic", "Visual", "99887"}
        };
    }

    @Test(dataProvider = "loginData", singleThreaded = true)
    public void fullEndToEndTest(String user, String pass, String fn, String ln, String pc) {
        setUp();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(12));
        System.out.println("\n=== 🔐 Starting test for: " + user + " ===");

        try {
            driver.get("https://www.saucedemo.com/");
            new LoginPage(driver).login(user, pass);

            // Handle alert if any
            try {
                Alert alert = driver.switchTo().alert();
                alert.dismiss();
                System.out.println("⚠️ Dismissed browser alert");
            } catch (NoAlertPresentException ignored) {}

            wait.until(ExpectedConditions.urlContains("inventory"));
            Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "❌ Login did not land on dashboard");
            System.out.println("✅ Landed on product/dashboard page");

            ProductPage pp = new ProductPage(driver);

            // Add two products
            doProductFlow(wait, "Sauce Labs Backpack");
            doProductFlow(wait, "Sauce Labs Bike Light");

            // Cart: remove bike light
            pp.goToCart();
            wait.until(ExpectedConditions.elementToBeClickable(By.id("remove-sauce-labs-bike-light"))).click();
            System.out.println("❌ Removed Bike Light");

            // Continue shopping
            wait.until(ExpectedConditions.elementToBeClickable(By.id("continue-shopping"))).click();
            System.out.println("➡️ Continue Shopping clicked");

            // Remove backpack if already added
            removeBackpackIfAlreadyInCart(wait);

            // Re-add Backpack
            WebElement reAdd = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-sauce-labs-backpack")));
            verifyColor(reAdd, "Re-add Backpack");
            reAdd.click();
            System.out.println("🛒 Re-added: Sauce Labs Backpack");

            pp.goToCart();

            // Checkout flow
            wait.until(ExpectedConditions.elementToBeClickable(By.id("checkout"))).click();
            System.out.println("➡️ Clicked Checkout");

            CheckoutPage cp = new CheckoutPage(driver);
            cp.fillForm(fn, ln, pc);
            cp.clickCancel();
            System.out.println("❌ Checkout cancelled");

            // Retry checkout
            pp.goToCart();
            wait.until(ExpectedConditions.elementToBeClickable(By.id("checkout"))).click();
            System.out.println("➡️ Checkout again");

            cp.fillForm(fn, ln, pc);
            cp.clickContinue();

            // Validate price breakdown
            String sub = driver.findElement(By.className("summary_subtotal_label")).getText();
            String tax = driver.findElement(By.className("summary_tax_label")).getText();
            String tot = driver.findElement(By.className("summary_total_label")).getText();
            System.out.println(sub + " | " + tax + " | " + tot);

            double s = Double.parseDouble(sub.split("\\$")[1]);
            double tx = Double.parseDouble(tax.split("\\$")[1]);
            double t = Double.parseDouble(tot.split("\\$")[1]);

            Assert.assertEquals(tx, 2.40, "❌ Tax mismatch");
            Assert.assertEquals(t, s + tx, "❌ Total mismatch");
            System.out.println("✅ Tax and total validated");

            // Finish
            WebElement finish = wait.until(ExpectedConditions.elementToBeClickable(By.id("finish")));
            verifyColor(finish, "Finish");
            finish.click();

            // Back Home
            WebElement home = wait.until(ExpectedConditions.elementToBeClickable(By.id("back-to-products")));
            verifyColor(home, "Back Home");
            home.click();

            // Logout with confirmation
            wait.until(ExpectedConditions.elementToBeClickable(By.id("react-burger-menu-btn"))).click();
            wait.until(ExpectedConditions.elementToBeClickable(By.id("logout_sidebar_link"))).click();
            System.out.println("👋 Logout clicked");

            // ✅ Wait for login page to confirm logout
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login-button")));
            System.out.println("✅ Login page visible again after logout");

            // Optional delay for visual confirmation before browser closes
            Thread.sleep(1000);

        } catch (Exception e) {
            System.err.println("❌ Test failed for user: " + user);
            e.printStackTrace();
            Assert.fail(e.getMessage());
        } finally {
            tearDown();
            System.out.println("=== ✅ Completed test for: " + user + " ===");
        }
    }

    private void doProductFlow(WebDriverWait wait, String name) {
        try {
            WebElement prod = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='" + name + "']")));
            prod.click();
            System.out.println("🔍 Opened: " + name);

            WebElement add = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@id,'add-to-cart')]")));
            verifyColor(add, "Add (" + name + ")");
            add.click();
            System.out.println("🛒 Added: " + name);

            try {
                WebElement back = wait.until(ExpectedConditions.elementToBeClickable(By.id("back-to-products")));
                back.click();
                System.out.println("↩️ Returned to products");
            } catch (TimeoutException e) {
                System.err.println("⚠️ 'Back to products' button not clickable or missing after adding product: " + name);
            }
        } catch (Exception e) {
            throw new RuntimeException("Product flow failed for: " + name, e);
        }
    }

    private void removeBackpackIfAlreadyInCart(WebDriverWait wait) {
        try {
            WebElement removeBtn = driver.findElement(By.id("remove-sauce-labs-backpack"));
            if (removeBtn.isDisplayed()) {
                removeBtn.click();
                System.out.println("🔁 Removed Backpack to allow re-add");
            }
        } catch (NoSuchElementException ignored) {}
    }

    private void verifyColor(WebElement el, String label) {
        String color = el.getCssValue("background-color");
        System.out.println("🎨 " + label + " color: " + color);
        Assert.assertTrue(color.contains("255, 255, 255") || color.contains("61, 220, 145"), "❌ " + label + " color mismatch");
    }
}
