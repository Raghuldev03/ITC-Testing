package filehandeling;

import java.io.File;

public class class1 {

	public static void main(String[] args) {
		 File file = new File("C:\\Users\\LabsKraft\\Desktop\\test.txt");
	        if (file.exists()) {
	            System.out.println("File exists");
	            System.out.println("Absolute Path: " + file.getAbsolutePath());
	        } else {
	            System.out.println("File does not exist");
	        }
	}

}
