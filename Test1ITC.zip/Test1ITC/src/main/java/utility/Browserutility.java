package utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
public class Browserutility {
    public static void scrollToElement(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }
    public static void clickElement(WebElement element) {
        element.click();
    }
    public static void enterText(WebElement element, String text) {
        element.clear();
        element.sendKeys(text);
    }
    public static String getPageTitle(WebDriver driver) {
        return driver.getTitle();
    }
}







