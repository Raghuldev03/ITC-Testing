package Abstraction;

abstract class brila{
	
	abstract void printinfo();
}

class emp extends brila{
	void printinfo() {
		System.out.println("from child brila...");
		
		String name="Ram";
		int age =21;
		float salary=34.89f;
		System.out.println("from brila..." + name);
		System.out.println("from brila..."+age);
		System.out.println("from brila..."+salary);
	}
}
public class abclass1 {
	
	
	public static void main(String[] args) {
		 brila t1=new emp();
		 t1.printinfo();
	}

}
