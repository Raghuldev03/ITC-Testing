package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class Class3 {

	public static void main(String[] args) {

		LinkedList<String> al=new LinkedList<String>();
		  al.add("Samsung");
		  al.add("LG");
		  al.add("Samsung");
		  al.add("Siemens");
		
		  Iterator<String> itr=al.iterator();
		  while(itr.hasNext()){
		   System.out.println(itr.next());
	}
	}
}
