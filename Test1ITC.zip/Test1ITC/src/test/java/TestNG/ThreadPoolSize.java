package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ThreadPoolSize {
	WebDriver driver;
  @Test(invocationCount =5,threadPoolSize = 3)
  public void f() {
	  WebDriverManager.chromedriver().setup();
      driver = new ChromeDriver();
      driver.get("https://www.selenium.dev/selenium/web/web-form.html");
	  System.out.println("hi") ;
	  }
}
