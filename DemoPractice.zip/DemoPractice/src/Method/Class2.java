package Method;

public class Class2 {
	void m1(int a, String b) {
		System.out.println("From Instance method");
		System.out.println(a);
		System.out.println(b);
	}
	static void m2(char x,double y) {
		System.out.println("From Static method");
		System.out.println(x);
		System.out.println(y);
	}
	public static void main(String[] args) {
		Class2.m2('A', 10.890);
		Class2 t=new Class2();
		t.m1(79, "Ram");
		t.m2('T', 56.098);

	}

}
