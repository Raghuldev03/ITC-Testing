package Exception;

public class class1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		System.out.println("hi  raghul");
		System.out.println("hi  raghul");
		System.out.println(10/0);
		System.out.println("hi  raghul");
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
