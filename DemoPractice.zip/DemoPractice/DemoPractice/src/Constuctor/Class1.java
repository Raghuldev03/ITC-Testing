package Constuctor;

public class Class1 {
	Class1(){
		System.out.println("From Constructor");
	}
	void m1() {
		System.out.println(10 + " From Instance method");
	}
	Class1(int a,String b){
		System.out.println("From Parameterized Constructor");
		System.out.println(a);
		System.out.println(b);
	}
	public static void main(String[] args) {
		Class1 t=new Class1();
		t.m1();
		Class1 t1=new Class1(10,"Raghul");

	}

}
