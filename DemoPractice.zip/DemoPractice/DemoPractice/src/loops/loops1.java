package loops;

public class loops1 {

	public static void main(String[] args) {
		int n=1;
		switch(n++) {
		case 1:
			System.out.println("Hi team");
			break;
		case 2:
			System.out.println("hello team");
			break;
		default:
			System.out.println("team");
		}
		System.out.println(n);
		
	}

}
