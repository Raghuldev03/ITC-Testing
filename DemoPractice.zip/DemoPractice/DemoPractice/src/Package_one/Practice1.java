package Package_one;

public class Practice1 {
	public static void main(String [] args) {
		int a=10;
		int b=10;
		System.out.println(a+b);
	}
}
