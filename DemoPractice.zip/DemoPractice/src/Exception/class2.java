package Exception;

public class class2 {
	static void age(int a) {
		if(a<18) {
			throw new ArithmeticException("Access Denined...");
		}
		else {
			System.out.println("Access Granted...");
		}
	}
	public static void main(String[] args) {
		try {
			int a=10;
			int b=0;
			System.out.println(a/b);
			}catch(Exception e) {
				System.out.println("Occured error : "+e);
			}
		   System.out.println("continuee...");
		  try {
			  int [] numbers= {10,20,30};
			  System.out.println(numbers[10]);
		  }catch (Exception e) {
			  System.out.println("Occured error : "+e);
		  }
		  finally {
			  System.out.println("continuee...");
		  }
		  
		  class2.age(56);
	}

}
