package Constuctor;

public class Class4 {
	int a;
	String b;
	float c;
	
	Class4(int x,String y, float z){
		this.a=x;
		this.b=y;
		this.c=z;
	}
	void dis() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
	public static void main(String[] args) {
		Class4 t=new Class4(20,"Rag",7.9f);
		t.dis();
		Class4 t1=new Class4(10,"Ram",6.9f);
		t1.dis();
	}

}
