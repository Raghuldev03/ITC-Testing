package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CheckoutPage {
    WebDriver driver;
    WebDriverWait wait;

    private By firstName = By.id("first-name");
    private By lastName = By.id("last-name");
    private By postalCode = By.id("postal-code");
    private By continueBtn = By.id("continue");
    private By cancelBtn = By.id("cancel");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void fillForm(String fn, String ln, String pc) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).sendKeys(fn);
        System.out.println("📝 First name: " + fn);
        Thread.sleep(500);

        wait.until(ExpectedConditions.visibilityOfElementLocated(lastName)).sendKeys(ln);
        System.out.println("📝 Last name: " + ln);
        Thread.sleep(500);

        wait.until(ExpectedConditions.visibilityOfElementLocated(postalCode)).sendKeys(pc);
        System.out.println("🏷️ Postal code: " + pc);
        Thread.sleep(500);
    }

    public void clickContinue() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(continueBtn)).click();
        System.out.println("➡️ Clicked Continue");
        Thread.sleep(500);
    }

    public void clickCancel() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(cancelBtn)).click();
        System.out.println("❌ Clicked Cancel");
        Thread.sleep(500);
    }
}
