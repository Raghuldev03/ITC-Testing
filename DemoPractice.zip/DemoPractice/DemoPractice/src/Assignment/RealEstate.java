package Assignment;

public class RealEstate {

	public static void main(String[] args) {
		double area = 1500;
        double rate = 5000;
        double basePrice = area * rate;
        double stampDuty = basePrice * 0.08;
        double gst = basePrice * 0.03;
        double total = basePrice + stampDuty + gst;
        System.out.printf("Base price: ₹%.2f%n", basePrice);
        System.out.printf("8%% Stamp Duty: ₹%.2f%n", stampDuty);
        System.out.printf("3%% GST: ₹%.2f%n", gst);
        System.out.printf("Total Agreed Value: ₹%.2f%n", total);

	}

}
