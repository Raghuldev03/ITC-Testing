package filehandeling;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class filereader {

	public static void main(String[] args) {
		try {
            FileReader fr = new FileReader("C:\\Users\\LabsKraft\\Desktop\\test.txt");
            BufferedReader br = new BufferedReader(fr);
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
            br.close(); // Also closes the FileReader
        } catch (IOException e) {
            e.printStackTrace();
        }

	}

}
