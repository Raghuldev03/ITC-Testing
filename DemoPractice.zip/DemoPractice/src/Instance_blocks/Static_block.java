package Instance_blocks;

public class Static_block {
	Static_block(){
		System.out.println("From Constructor...");
	}{
		System.out.println("From Instance 1 Block....");
	}
	
	Static_block(int a){
		System.out.println("From Parameter Constructor...");
	}
	{
		System.out.println("From Instance 2 Block....");
	}
	static {
		System.out.println("From Static 1st Block....");
	}
	static {
		System.out.println("From Static 2nd Block....");
	}
	
	
	public static void main(String[] args) {
		new Static_block();
		//new Static_block(10);
	}
}
